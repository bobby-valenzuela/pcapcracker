Harken unto me, lo and Beholdeth thine steps:

Stepeth 1: Cast thine pcap files into the folder titled "pcaps".
Stepeth 2: Delete the sample wordlist thereof (titled "wordlist.txt") and add in your own with the same name ("wordlist.txt") that thou might enjoy a host potential matches. 
Stepeth 3: Runneth the "pcapcracker.exe" executable and reap the fruit thereof.

Dost thou yern for a new wordlist?

https://weakpass.com/wordlist